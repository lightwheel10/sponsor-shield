(() => {
  "use strict";
  const logic = ShieldLogic;
  const state = {
    videoId: null, raw: [], ranges: [], load: "idle", error: null, refreshError: null, refreshCount: 0,
    settings: {enabled: true, includeSelfpromo: false}, ready: false
  };
  let generation = 0;
  let video = null;
  let player = null;
  let timer = null;
  let overlay = null;
  let label = null;
  let active = null;
  let changedMute = false;
  let queued = false;
  let refreshScheduler = null;
  let inFlight = null;
  const overrideRanges = [];
  function rememberOverride(range) {
    if (!overrideRanges.some(saved => saved.key === range.key)) overrideRanges.push({...range});
  }
  function rebuildRanges() {
    state.ranges = logic.mergeSegments(state.raw, state.settings.includeSelfpromo)
      .map(range => ({...range, source: "sponsorblock"}));
  }
  function refreshActivity() {
    refreshScheduler?.setActive(Boolean(state.ready && state.settings.enabled && state.videoId && video?.isConnected
      && !video.paused && !video.ended && document.visibilityState !== "hidden"
      && !player?.classList.contains("ad-showing")));
  }
  const events = ["timeupdate", "seeking", "seeked", "ratechange", "play", "playing", "pause", "ended", "loadedmetadata", "emptied"];
  const adObserver = new MutationObserver(() => { refreshActivity(); update(); });

  function release() {
    clearTimeout(timer);
    timer = null;
    if (video) {
      video.classList.remove("ytss-blurred");
      // A mute that existed before entry belongs to the user.
      if (changedMute && video.muted) video.muted = false;
    }
    changedMute = false;
    active = null;
    if (overlay) overlay.hidden = true;
  }
  function showAnyway() {
    if (active) rememberOverride(active);
    release();
    update();
  }
  function onVolume() {
    if (active && video && !video.muted) {
      rememberOverride(active);
      changedMute = false;
      release();
      update();
    }
  }
  function createOverlay() {
    if (overlay?.parentElement === player) return;
    overlay?.remove();
    overlay = document.createElement("div");
    overlay.className = "ytss-overlay";
    overlay.hidden = true;
    const card = document.createElement("div");
    card.className = "ytss-card";
    label = document.createElement("span");
    label.setAttribute("role", "status");
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "Show anyway";
    button.addEventListener("click", showAnyway);
    card.append(label, button);
    overlay.append(card);
    player.append(overlay);
  }
  function bind(nextVideo, nextPlayer) {
    if (nextVideo === video && nextPlayer === player) return;
    release();
    if (video) {
      events.forEach(event => video.removeEventListener(event, onTiming));
      video.removeEventListener("volumechange", onVolume);
    }
    adObserver.disconnect();
    overlay?.remove();
    overlay = null;
    video = nextVideo;
    player = nextPlayer;
    if (video) {
      events.forEach(event => video.addEventListener(event, onTiming));
      video.addEventListener("volumechange", onVolume);
    }
    if (player) adObserver.observe(player, {attributes: true, attributeFilter: ["class"]});
  }
  function onTiming() { sync(); }
  function update() {
    clearTimeout(timer);
    timer = null;
    const current = video && logic.segmentAt(state.ranges, video.currentTime);
    const eligible = state.ready && state.settings.enabled && state.videoId
      && state.videoId === logic.videoIdFromUrl(location.href) && video?.isConnected && player?.isConnected
      && video.readyState >= 2 && !video.seeking && !player.classList.contains("ad-showing");
    if (!eligible || !current || logic.rememberedRange(overrideRanges, current)) {
      release();
    } else {
      if (active?.key !== current.key) {
        release();
        active = current;
        if (!video.muted) { changedMute = true; video.muted = true; }
      }
      video.classList.add("ytss-blurred");
      createOverlay();
      const text = `Sponsor segment — ends in ${Math.max(1, Math.ceil(current.end - video.currentTime))}s`;
      if (label.textContent !== text) label.textContent = text;
      overlay.hidden = false;
    }
    // currentTime remains the authority: a timer merely asks for another check.
    if (eligible) {
      const delay = logic.boundaryDelay(state.ranges, video.currentTime, video.playbackRate, video.paused || video.ended);
      if (delay !== null) timer = setTimeout(sync, delay);
    }
  }
  async function loadSegments(refresh = false) {
    if (inFlight?.generation === generation) return {error: true};
    const requestGeneration = generation;
    const videoId = state.videoId;
    const token = {generation: requestGeneration};
    inFlight = token;
    if (!refresh) { state.load = "loading"; state.error = null; }
    let outcome;
    try {
      const result = await chrome.runtime.sendMessage({type: "GET_SEGMENTS", videoId, refresh});
      if (generation !== requestGeneration || state.videoId !== videoId
          || logic.videoIdFromUrl(location.href) !== videoId) return {error: true};
      if (!result?.ok || result.videoId !== videoId) throw Object.assign(new Error(result?.error || "Segment lookup failed"), {retryAfterMs: result?.retryAfterMs || 0});
      const incoming = logic.extractSegments([{videoID: videoId, segments: result.segments}], videoId);
      if (refresh) {
        const byId = new Map(incoming.map(item => [item.UUID, item]));
        for (const old of state.raw) if (!byId.has(old.UUID)) byId.set(old.UUID, old);
        state.raw = [...byId.values()].slice(0, 1000);
        state.refreshCount++;
      } else state.raw = incoming;
      rebuildRanges();
      state.load = "loaded";
      state.error = null;
      state.refreshError = null;
      outcome = {count: incoming.length};
    } catch (error) {
      if (generation !== requestGeneration || state.videoId !== videoId) return {error: true};
      if (refresh && state.load === "loaded") state.refreshError = error.message;
      else { state.load = "error"; state.error = error.message; }
      outcome = {error: true, retryAfterMs: error.retryAfterMs || 0};
    } finally { if (inFlight === token) inFlight = null; }
    if (!refresh) refreshScheduler?.settle(outcome);
    sync();
    return outcome;
  }
  function sync() {
    const id = logic.videoIdFromUrl(location.href);
    if (id !== state.videoId) {
      generation++;
      refreshScheduler?.dispose();
      refreshScheduler = null;
      release();
      state.videoId = id;
      state.raw = [];
      state.ranges = [];
      state.refreshError = null;
      state.refreshCount = 0;
      state.load = "idle";
      state.error = null;
      overrideRanges.length = 0;
      if (id) refreshScheduler = ShieldRefresh.createRefreshScheduler({refresh: () => loadSegments(true)});
    }
    const nextPlayer = id ? document.querySelector("#movie_player") : null;
    bind(nextPlayer?.querySelector("video.html5-main-video") || nextPlayer?.querySelector("video") || null, nextPlayer);
    refreshActivity();
    if (id && state.ready && state.settings.enabled && state.load === "idle") void loadSegments();
    update();
  }
  function queueSync() {
    if (queued) return;
    queued = true;
    queueMicrotask(() => { queued = false; sync(); });
  }
  function status() {
    sync();
    return {
      videoId: state.videoId, enabled: state.settings.enabled,
      includeSelfpromo: state.settings.includeSelfpromo, load: state.load, error: state.error,
      sources: {sponsorblock: state.ranges.length},
      ranges: state.ranges.map(r => ({...r})),
      refreshCount: state.refreshCount, refreshError: state.refreshError, refresh: refreshScheduler?.status() || null,
      segmentsFound: state.ranges.length, active: Boolean(active),
      overridden: Boolean(video && logic.rememberedRange(overrideRanges, logic.segmentAt(state.ranges, video.currentTime))),
      adPlaying: Boolean(player?.classList.contains("ad-showing"))
    };
  }
  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message?.type === "GET_STATUS") reply(status());
    if (message?.type === "RETRY_SEGMENTS" && state.videoId && state.load === "error") {
      state.load = "idle";
      sync();
      reply(status());
    }
  });
  function setSettings(values) {
    state.settings = {enabled: values.enabled !== false, includeSelfpromo: values.includeSelfpromo === true};
    state.ready = true;
    rebuildRanges();
    sync();
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    const values = {...state.settings};
    for (const key of ["enabled", "includeSelfpromo"]) {
      if (changes[key]) values[key] = changes[key].newValue;
    }
    setSettings(values);
  });
  chrome.storage.local.get({enabled: true, includeSelfpromo: false}).then(setSettings)
    .catch(() => setSettings({enabled: false, includeSelfpromo: false}));
  document.addEventListener("visibilitychange", refreshActivity);
  new MutationObserver(queueSync).observe(document.documentElement, {childList: true, subtree: true});
  ["yt-navigate-finish", "yt-page-data-updated", "popstate"].forEach(event => window.addEventListener(event, queueSync));
  window.addEventListener("pagehide", () => { release(); refreshScheduler?.setActive(false); });
  window.addEventListener("pageshow", queueSync);
  // URL fallback for history changes with no corresponding DOM/navigation event.
  setInterval(() => { if (logic.videoIdFromUrl(location.href) !== state.videoId) sync(); }, 1000);
  sync();
})();
