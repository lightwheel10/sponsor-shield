"use strict";
const enabled = document.querySelector("#enabled");
const selfpromo = document.querySelector("#includeSelfpromo");
const statusText = document.querySelector("#status");
const details = document.querySelector("#details");
const retry = document.querySelector("#retry");
const saveError = document.querySelector("#save-error");

async function currentStatus(type = "GET_STATUS") {
  retry.hidden = true;
  try {
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    const status = await chrome.tabs.sendMessage(tab.id, {type});
    if (!status?.videoId) {
      statusText.textContent = "Open a YouTube watch page";
      details.textContent = "Regular videos are supported. Shorts and embeds are outside v1.";
    } else if (!enabled.checked) {
      statusText.textContent = "Shield is off";
      details.textContent = "Turn it on to shield sponsor segments.";
    } else if (status.load === "error") {
      statusText.textContent = "Couldn’t check segments";
      details.textContent = `${status.error} · SponsorBlock: ${status.sources?.sponsorblock || 0}`;
      retry.hidden = false;
    } else if (status.load !== "loaded") {
      statusText.textContent = "Checking segment data…";
      details.textContent = "The video keeps playing while the lookup finishes.";
    } else {
      const count = status.segmentsFound;
      statusText.textContent = status.adPlaying ? "Paused for a YouTube ad"
        : status.active ? "Shielding a sponsor segment"
        : status.overridden ? "Showing this segment by your choice"
        : count === 0 ? "No segments found" : "Ready for the next segment";
      details.textContent = `${count} ${count === 1 ? "segment" : "segments"} found · SponsorBlock: ${status.sources?.sponsorblock || 0} · ${status.videoId}`;
      if (status.refreshError) details.textContent += " · Refresh delayed; keeping previous data";
    }
  } catch {
    statusText.textContent = "Open a YouTube watch page";
    details.textContent = "After installing, reload any YouTube tabs that were already open.";
  }
}
async function save(input, key) {
  input.disabled = true;
  saveError.hidden = true;
  try {
    await chrome.storage.local.set({[key]: input.checked});
    await currentStatus();
  } catch {
    input.checked = !input.checked;
    saveError.textContent = "Couldn’t save this setting. Please try again.";
    saveError.hidden = false;
  } finally { input.disabled = false; }
}
enabled.addEventListener("change", () => save(enabled, "enabled"));
selfpromo.addEventListener("change", () => save(selfpromo, "includeSelfpromo"));
retry.addEventListener("click", () => currentStatus("RETRY_SEGMENTS"));
chrome.storage.local.get({enabled: true, includeSelfpromo: false}).then(values => {
  enabled.checked = values.enabled !== false;
  selfpromo.checked = values.includeSelfpromo === true;
  void currentStatus();
}).catch(() => {
  saveError.textContent = "Couldn’t load settings. Close and reopen this popup.";
  saveError.hidden = false;
});
setInterval(currentStatus, 1000);
